package com.example.cs360weighttrackingapp_shaw;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/*
 * DatabaseHelper class handles everything related to the local SQLite database.
 * It stores users, their daily weights, and each users goal weight.
 */
public class DBHelper extends SQLiteOpenHelper {

    // Database info
    private static final String DATABASE_NAME = "WeightTracker.db";
    private static final int DATABASE_VERSION = 1;

    // User Table
    private static final String TABLE_USERS = "tbl_users";
    private static final String COL_USERNAME = "username";
    private static final String COL_PASSWORD = "password";

    // Weight Log Table
    private static final String TABLE_LOGS = "tbl_logs";
    private static final String COL_LOG_ID = "log_id";
    private static final String COL_LOG_USERNAME = "username";
    private static final String COL_LOG_DATE = "date";
    private static final String COL_LOG_WEIGHT = "weight";

    // Goal Table
    private static final String TABLE_GOALS = "tbl_goals";
    private static final String COL_GOAL_USERNAME = "username";
    private static final String COL_GOAL_VALUE = "goal_weight";

    //Constructor
    public DBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    // Creates all tables
    @Override
    public void onCreate(SQLiteDatabase db) {
        // User table (for login)
        db.execSQL("CREATE TABLE " + TABLE_USERS + " ("
                + COL_USERNAME + " TEXT PRIMARY KEY, "
                + COL_PASSWORD + " TEXT NOT NULL)");

        // Weight log table (for daily weight tracking)
        db.execSQL("CREATE TABLE " + TABLE_LOGS + " ("
                + COL_LOG_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COL_LOG_USERNAME + " TEXT NOT NULL, "
                + COL_LOG_DATE + " TEXT NOT NULL, "
                + COL_LOG_WEIGHT + " REAL NOT NULL)");

        // Goal table (for saving user goal weight)
        db.execSQL("CREATE TABLE " + TABLE_GOALS + " ("
                + COL_GOAL_USERNAME + " TEXT PRIMARY KEY, "
                + COL_GOAL_VALUE + " REAL)");
    }

    // Called when upgrading version, wipes and recreates database
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_LOGS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_GOALS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        onCreate(db);
    }

    // creates a new user account
    public boolean createUser(String username, String password) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_USERNAME, username.trim());
        values.put(COL_PASSWORD, password);

        long result = -1;
        try {
            result = db.insertOrThrow(TABLE_USERS, null, values);
        } catch (SQLException ignored) {
            // Username already exists
        }
        return result != -1;  // True if success, false if duplicate
    }

    // Checks if username and password match
    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query(
                TABLE_USERS,
                new String[]{COL_USERNAME},
                COL_USERNAME + "=? AND " + COL_PASSWORD + "=?",
                new String[]{username.trim(), password},
                null, null, null
        );
        boolean valid = (c != null && c.moveToFirst());
        if (c != null) c.close();
        return valid;
    }

    //Adds a new weight entry
    public long addWeight(String username, String date, double weight) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_LOG_USERNAME, username.trim());
        values.put(COL_LOG_DATE, date.trim());
        values.put(COL_LOG_WEIGHT, weight);
        return db.insert(TABLE_LOGS, null, values);
    }

    // Updates an entry
    public int updateWeight(long id, String date, double weight) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_LOG_DATE, date.trim());
        values.put(COL_LOG_WEIGHT, weight);
        return db.update(TABLE_LOGS, values, COL_LOG_ID + "=?", new String[]{String.valueOf(id)});
    }

    // Deletes a log entry
    public int deleteWeight(long id) {
        SQLiteDatabase db = getWritableDatabase();
        return db.delete(TABLE_LOGS, COL_LOG_ID + "=?", new String[]{String.valueOf(id)});
    }

    //gets all weights for one user
    public Cursor getWeights(String username) {
        SQLiteDatabase db = getReadableDatabase();
        return db.query(
                TABLE_LOGS,
                new String[]{COL_LOG_ID, COL_LOG_DATE, COL_LOG_WEIGHT},
                COL_LOG_USERNAME + "=?",
                new String[]{username.trim()},
                null, null,
                COL_LOG_DATE + " DESC"
        );
    }

    // Saves or updates a goal for this user
    public boolean setGoal(String username, Double goal) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_GOAL_VALUE, goal);

        // Tries updating goal first
        int updated = db.update(TABLE_GOALS, values, COL_GOAL_USERNAME + "=?", new String[]{username.trim()});
        if (updated > 0) return true;

        // Otherwise inserts a new goal
        values.put(COL_GOAL_USERNAME, username.trim());
        long result = db.insert(TABLE_GOALS, null, values);
        return result != -1;
    }

    // Retrieves saved goal weight
    public Double getGoal(String username) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query(
                TABLE_GOALS,
                new String[]{COL_GOAL_VALUE},
                COL_GOAL_USERNAME + "=?",
                new String[]{username.trim()},
                null, null, null
        );
        Double goal = null;
        if (c != null && c.moveToFirst()) {
            if (!c.isNull(0)) goal = c.getDouble(0);
        }
        if (c != null) c.close();
        return goal;
    }
}
