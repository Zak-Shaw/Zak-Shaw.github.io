package com.example.cs360weighttrackingapp_shaw;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

/*
 * Shows the users saved goal weight.
 * Saves a new goal using DBHelper.
 * Home button returns to the weights screen.
 */
public class GoalActivity extends AppCompatActivity {

    private static final String PREFS = "auth_prefs";
    private static final String KEY_CURRENT_USER = "current_user";

    // Database and UI references
    private TextView tvCurrentGoal;
    private EditText etGoal;
    private Button btnSave;
    private Button btnHome;
    private DBHelper db;
    private String currentUser = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_goal);

        // find views by id
        tvCurrentGoal = findViewById(R.id.tvCurrentGoal);
        etGoal = findViewById(R.id.etGoalWeight);
        btnSave = findViewById(R.id.btnSaveGoal);
        btnHome = findViewById(R.id.btnHome);

        // SMS settings button
        Button btnOpenSms = findViewById(R.id.btnOpenSmsSettings);

        db = new DBHelper(this);
        currentUser = readCurrentUser();

        // loads and display saved goal
        updateGoalDisplay();

        // save button
        btnSave.setOnClickListener(v -> saveGoal());

        // home button to go back to weights page
        btnHome.setOnClickListener(v -> finish());

        // open SMS settings page
        btnOpenSms.setOnClickListener(v ->
                startActivity(new android.content.Intent(this, SmsActivity.class)));

    }

    // Reads the saved username
    private String readCurrentUser() {
        SharedPreferences sp = getSharedPreferences(PREFS, MODE_PRIVATE);
        return sp.getString(KEY_CURRENT_USER, "");
    }

    // Pulls goal from the database and show it
    private void updateGoalDisplay() {
        Double goal = db.getGoal(currentUser);
        if (goal == null) {
            tvCurrentGoal.setText("Current goal: —");
        } else {
            tvCurrentGoal.setText("Current goal: " + goal);
        }
    }

    // Validates and saves to the database
    private void saveGoal() {
        String gStr = safeText(etGoal);
        if (TextUtils.isEmpty(gStr)) {
            toast("Enter a goal weight");
            return;
        }

        double goalValue;
        try {
            goalValue = Double.parseDouble(gStr);
        } catch (NumberFormatException e) {
            toast("Goal must be a number");
            return;
        }

        boolean ok = db.setGoal(currentUser, goalValue);
        if (ok) {
            toast("Goal saved");
            updateGoalDisplay();
            hideKeyboardFrom(etGoal);
            etGoal.setText("");
            etGoal.clearFocus();
        } else {
            toast("Failed to save goal");
        }
    }

    // Reads text safely and trim it
    private String safeText(EditText e) {
        CharSequence cs = e.getText();
        return cs == null ? "" : cs.toString().trim();
    }

    // Quick toast helper
    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }

    // Helper to hide keyboard
    private void hideKeyboardFrom(android.view.View view) {
        android.view.inputmethod.InputMethodManager imm =
                (android.view.inputmethod.InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        if (imm != null && view != null) {
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
    }
}
