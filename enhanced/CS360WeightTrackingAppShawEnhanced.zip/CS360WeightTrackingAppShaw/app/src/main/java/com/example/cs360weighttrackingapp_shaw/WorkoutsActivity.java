package com.example.cs360weighttrackingapp_shaw;

import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

/*
 * Shows the logged-in user's workout entries from DBHelper.
 * Lets the user add a new workout row and delete them.
 */
public class WorkoutsActivity extends AppCompatActivity {

    private static final String PREFS = "auth_prefs";
    private static final String KEY_CURRENT_USER = "current_user";

    // Database and UI references
    private DBHelper db;
    private LinearLayout rowsContainer;
    private EditText etDate;
    private EditText etDuration;
    private EditText etType;
    private Button btnAdd;
    private Button btnWeights;
    private Button btnSortWorkouts;
    private Button btnCalculateWorkouts;
    private boolean sortNewestFirst = true;

    // Logged in username
    private String currentUser = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_workouts);

        // find views by id
        rowsContainer = findViewById(R.id.rowsContainerWorkouts);
        etDate = findViewById(R.id.WorkoutDate);
        etDuration = findViewById(R.id.WorkoutDuration);
        etType = findViewById(R.id.WorkoutType);
        btnAdd = findViewById(R.id.WorkoutAddButton);
        btnWeights = findViewById(R.id.btnWeights);
        btnSortWorkouts = findViewById(R.id.btnSortWorkouts);
        btnCalculateWorkouts = findViewById(R.id.btnCalculateWorkouts);

        // setup DB helper
        db = new DBHelper(this);

        // loads the saved username from LoginActivity
        currentUser = readCurrentUser();
        if (TextUtils.isEmpty(currentUser)) {
            toast("No user logged in. Returning to Login.");
            startActivity(new Intent(this, LoginActivity.class));
            finish();
            return;
        }

        // Adds a new workout entry
        btnAdd.setOnClickListener(v -> addWorkout());

        // Goes back to Weights screen
        btnWeights.setOnClickListener(v -> {
            startActivity(new Intent(this, DataGridActivity.class));
            finish();
        });

        btnSortWorkouts.setOnClickListener(v -> {
            sortNewestFirst = !sortNewestFirst;
            refreshGrid();
        });

        btnCalculateWorkouts.setOnClickListener(v -> calculateWorkoutTotals());

        // First load of data
        refreshGrid();
    }

    // Reads the saved username from SharedPreferences
    private String readCurrentUser() {
        SharedPreferences sp = getSharedPreferences(PREFS, MODE_PRIVATE);
        return sp.getString(KEY_CURRENT_USER, "");
    }

    // Adds a new workout to the DB, then refresh the list
    private void addWorkout() {
        String date = safeText(etDate);
        String dStr = safeText(etDuration);
        String type = safeText(etType);

        if (date.isEmpty() || dStr.isEmpty() || type.isEmpty()) {
            toast("Enter date, duration, and type");
            return;
        }

        // checks the date format is MM/DD/YY or MM/DD/YYYY
        if (!date.matches("^\\d{1,2}/\\d{1,2}/(\\d{2}|\\d{4})$")) {
            toast("Please enter date as MM/DD/YY or MM/DD/YYYY");
            return;
        }

        double durationMinutes;
        try {
            durationMinutes = parseDurationToMinutes(dStr);
        } catch (IllegalArgumentException e) {
            toast(e.getMessage());
            return;
        }

        long res = db.addWorkout(currentUser, date, durationMinutes, type);
        if (res == -1) {
            toast("Failed to add workout");
        } else {
            toast("Added " + date + " - " + durationMinutes + " - " + type);
            hideKeyboardFrom(etType);
            etDate.setText("");
            etDuration.setText("");
            etType.setText("");
            etDate.clearFocus();
            etDuration.clearFocus();
            etType.clearFocus();
            refreshGrid();
        }
    }

    // Converts everything into total minutes.
    // If no unit is provided, assume minutes.
    private double parseDurationToMinutes(String input) {
        if (input == null) throw new IllegalArgumentException("Enter a duration");

        String s = input.trim().toLowerCase();
        if (s.isEmpty()) throw new IllegalArgumentException("Enter a duration");

        // Pull out the first number (supports "1.5", "48", "  2 ")
        java.util.regex.Matcher m = java.util.regex.Pattern
                .compile("([0-9]+(\\.[0-9]+)?)")
                .matcher(s);

        if (!m.find()) {
            throw new IllegalArgumentException("Duration must start with a number (ex: 45 min, 1.5 hr)");
        }

        double value = Double.parseDouble(m.group(1));

        // Decide units
        boolean isHours = s.contains("hour") || s.contains("hr") || s.contains("hrs");
        boolean isMinutes = s.contains("min") || s.contains("mins") || s.contains("minute") || s.contains("minutes");

        // If both show up somehow, treat as invalid to avoid confusing math later
        if (isHours && isMinutes) {
            throw new IllegalArgumentException("Use only one unit: minutes OR hours (ex: 45 min or 1.5 hr)");
        }

        if (isHours) {
            return value * 60.0;
        }

        // default to minutes if minutes listed or no unit provided
        return value;
    }

    // Helper to hide keyboard
    private void hideKeyboardFrom(android.view.View view) {
        android.view.inputmethod.InputMethodManager imm =
                (android.view.inputmethod.InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        if (imm != null && view != null) {
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
    }

    // Pulls all rows for this user and draw them into rowsContainer
    private void refreshGrid() {
        rowsContainer.removeAllViews();

        String orderBy = sortNewestFirst ? "workout_id DESC" : "workout_id ASC";
        Cursor c = db.getWorkouts(currentUser, orderBy);
        if (c == null) return;

        while (c.moveToNext()) {
            long id = c.getLong(0);
            String date = c.getString(1);
            double duration = c.getDouble(2);
            String type = c.getString(3);

            addRowView(id, date, duration, type);
        }
        c.close();
    }

    // Calculates total workout time for the user
    private void calculateWorkoutTotals() {
        String orderBy = "workout_id DESC"; // order doesn't matter for totals
        Cursor c = db.getWorkouts(currentUser, orderBy);

        if (c == null) {
            Toast.makeText(this, "No workout data found.", Toast.LENGTH_SHORT).show();
            return;
        }

        int count = 0;
        double totalMinutes = 0;

        while (c.moveToNext()) {
            // Columns: workout_id, date, duration, type
            double minutes = c.getDouble(2);
            totalMinutes += minutes;
            count++;
        }
        c.close();

        if (count == 0) {
            Toast.makeText(this, "Add at least one workout first.", Toast.LENGTH_SHORT).show();
            return;
        }

        String pretty = formatMinutes(totalMinutes);
        String msg = "Total: " + pretty + " (" + count + " workouts)";
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
    }

    // Converts total minutes to hours and minutes
    private String formatMinutes(double minutes) {
        int total = (int) Math.round(minutes);
        int hrs = total / 60;
        int mins = total % 60;

        if (hrs <= 0) {
            return mins + "m";
        }
        if (mins == 0) {
            return hrs + "h";
        }
        return hrs + "h " + mins + "m";
    }

    // Create one horizontal row: [Date] [Duration] [Type] [Delete X]
    private void addRowView(long id, String date, double duration, String type) {
        // Parent row horizontal
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(dp(8), dp(8), dp(8), dp(8));
        row.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));

        // Date column (weight = 1)
        TextView tvDate = new TextView(this);
        tvDate.setLayoutParams(weighted(1));
        tvDate.setText(date);
        tvDate.setTextSize(14);
        tvDate.setGravity(Gravity.START);
        tvDate.setPadding(0, 0, dp(8), 0);
        tvDate.setTypeface(tvDate.getTypeface(), android.graphics.Typeface.BOLD);
        tvDate.setSingleLine(true);
        tvDate.setEllipsize(android.text.TextUtils.TruncateAt.END);

        // Duration column (weight = 1)
        TextView tvDuration = new TextView(this);
        tvDuration.setLayoutParams(weighted(1));
        tvDuration.setText(String.format(java.util.Locale.US, "%.0f", duration));
        tvDuration.setTextSize(16);
        tvDuration.setGravity(Gravity.START);

        // Type column (weight = 2)
        TextView tvType = new TextView(this);
        tvType.setLayoutParams(weighted(2));
        tvType.setText(type);
        tvType.setTextSize(16);
        tvType.setGravity(Gravity.START);

        // Delete button (fixed size red "X")
        Button btnDelete = new Button(this);
        LinearLayout.LayoutParams delParams =
                new LinearLayout.LayoutParams(dp(36), dp(36));
        btnDelete.setLayoutParams(delParams);
        btnDelete.setText("X");
        btnDelete.setAllCaps(false);
        btnDelete.setTextColor(0xFFFFFFFF);
        btnDelete.setBackgroundColor(0xFFEF5350);
        btnDelete.setOnClickListener(v -> {
            db.deleteWorkout(id);
            refreshGrid();
        });

        // Adds children to row and row to container
        row.addView(tvDate);
        row.addView(tvDuration);
        row.addView(tvType);
        row.addView(btnDelete);
        rowsContainer.addView(row);
    }

    // Helpers for layout weights
    private LinearLayout.LayoutParams weighted(int weight) {
        LinearLayout.LayoutParams p =
                new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.weight = weight;
        return p;
    }

    private int dp(int value) {
        float d = getResources().getDisplayMetrics().density;
        return Math.round(value * d);
    }

    // Reads text safely and trim it
    private String safeText(EditText e) {
        CharSequence cs = e.getText();
        return cs == null ? "" : cs.toString().trim();
    }

    // Quick toast helper
    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }
}

