package com.example.cs360weighttrackingapp_shaw;

import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.Manifest;
import android.content.pm.PackageManager;
import android.telephony.SmsManager;
import androidx.core.content.ContextCompat;

import androidx.appcompat.app.AppCompatActivity;

/*
 * Shows the logged-in user's weight entries from DBHelper.
 * Lets the user add a new date and weight row and delete them.
 */
public class DataGridActivity extends AppCompatActivity {

    private static final String PREFS = "auth_prefs";
    private static final String KEY_CURRENT_USER = "current_user";
    private static final String KEY_NOTIFY_PHONE = "notify_phone";

    // Database and UI references
    private DBHelper db;
    private LinearLayout rowsContainer;
    private EditText etDate;
    private EditText etWeight;
    private Button btnAdd;
    private Button btnEditGoal;
    private Button btnWorkouts;
    private Button btnCalculate;
    private Button btnSort;
    private boolean sortNewestFirst = true;

    // Logged in username
    private String currentUser = "";

    // Reads the saved phone number that is set on the SMS screen
    private String getNotifyPhone() {
        return getSharedPreferences(PREFS, MODE_PRIVATE).getString(KEY_NOTIFY_PHONE, "");
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_grid);

        // find views by id
        rowsContainer = findViewById(R.id.rowsContainer);
        etDate = findViewById(R.id.DateLabel);
        etWeight = findViewById(R.id.WeightValue);
        btnAdd = findViewById(R.id.WeightAddButton);
        btnEditGoal = findViewById(R.id.btnEditGoal);
        btnWorkouts = findViewById(R.id.btnWorkouts);
        btnSort = findViewById(R.id.btnSort);
        btnCalculate = findViewById(R.id.btnCalculate);

        // setup DB helper
        db = new DBHelper(this);

        //loads the saved username from LoginActivity
        currentUser = readCurrentUser();
        if (TextUtils.isEmpty(currentUser)) {
            toast("No user logged in. Returning to Login.");
            startActivity(new Intent(this, LoginActivity.class));
            finish();
            return;
        }

        // Adds a new weight entry
        btnAdd.setOnClickListener(v -> addWeight());

        // Goes to Goal screen
        btnEditGoal.setOnClickListener(v ->
                startActivity(new Intent(this, GoalActivity.class)));

        // Goes to the Workouts screen
        btnWorkouts.setOnClickListener(v -> {
            Intent intent = new Intent(DataGridActivity.this, WorkoutsActivity.class);
            startActivity(intent);
        });

        btnCalculate.setOnClickListener(v -> calculateProgress());

        // Sorts by date
        btnSort.setOnClickListener(v -> {
            sortNewestFirst = !sortNewestFirst;
            refreshGrid();
        });

        // First load of data
        refreshGrid();
    }

    // Reads the saved username from SharedPreferences
    private String readCurrentUser() {
        SharedPreferences sp = getSharedPreferences(PREFS, MODE_PRIVATE);
        return sp.getString(KEY_CURRENT_USER, "");
    }

    // Adds a new date and weight to the DB, then refresh the list
    private void addWeight() {
        String date = safeText(etDate);
        String wStr = safeText(etWeight);

        if (date.isEmpty() || wStr.isEmpty()) {
            toast("Enter date and weight");
            return;
        }

        // checks the date format is MM/DD/YY or MM/DD/YYYY
        if (!date.matches("^\\d{1,2}/\\d{1,2}/(\\d{2}|\\d{4})$")) {
            toast("Please enter date as MM/DD/YY or MM/DD/YYYY");
            return;
        }

        double weightVal;
        try {
            weightVal = Double.parseDouble(wStr);
        } catch (NumberFormatException e) {
            toast("Weight must be a number");
            return;
        }

        long res = db.addWeight(currentUser, date, weightVal);
        if (res == -1) {
            toast("Failed to add weight");
        } else {
            toast("Added " + date + " - " + weightVal);
            hideKeyboardFrom(etWeight);
            etDate.setText("");
            etWeight.setText("");
            etDate.clearFocus();
            etWeight.clearFocus();
            refreshGrid();

            // check goal and send a single SMS if reached
            maybeSendGoalReachedSms(weightVal);
        }
    }

    // Helper to hide keyboard
    private void hideKeyboardFrom(android.view.View view) {
        android.view.inputmethod.InputMethodManager imm =
                (android.view.inputmethod.InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        if (imm != null && view != null) {
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
    }

    // Pulls all rows for this user and draw them into rowsContainer
    private void refreshGrid() {
        rowsContainer.removeAllViews();

        String orderBy = sortNewestFirst ? "log_id DESC" : "log_id ASC";
        Cursor c = db.getWeights(currentUser, orderBy);
        if (c == null) return;

        while (c.moveToNext()) {
            long id = c.getLong(0);
            String date = c.getString(1);
            double weight = c.getDouble(2);

            addRowView(id, date, weight);
        }
        c.close();
    }

    // Calculates the difference between the user's oldest and newest weight entries
    private void calculateProgress() {
        Cursor oldest = db.getOldestWeight(currentUser);
        Cursor newest = db.getNewestWeight(currentUser);

        if (oldest == null || newest == null) {
            Toast.makeText(this, "No weight data found.", Toast.LENGTH_SHORT).show();
            return;
        }

        // Need at least one row in each cursor
        if (!oldest.moveToFirst() || !newest.moveToFirst()) {
            Toast.makeText(this, "Add at least two weight entries first.", Toast.LENGTH_SHORT).show();
            oldest.close();
            newest.close();
            return;
        }

        // If there is only one entry, oldest and newest will be the same row.
        long oldestId = oldest.getLong(0);
        long newestId = newest.getLong(0);

        if (oldestId == newestId) {
            Toast.makeText(this, "Add at least two weight entries first.", Toast.LENGTH_SHORT).show();
            oldest.close();
            newest.close();
            return;
        }

        // Columns returned: log_id, date, weight
        String startDate = oldest.getString(1);
        double startWeight = oldest.getDouble(2);

        String currentDate = newest.getString(1);
        double currentWeight = newest.getDouble(2);

        oldest.close();
        newest.close();

        double diff = currentWeight - startWeight;   // positive = gained, negative = lost
        double absDiff = Math.abs(diff);

        String msg;
        if (diff == 0) {
            msg = "No change since " + startDate + ".";
        } else if (diff < 0) {
            msg = "Down " + String.format(java.util.Locale.US, "%.1f", absDiff)
                    + " lbs since " + startDate + " (as of " + currentDate + ").";
        } else {
            msg = "Up " + String.format(java.util.Locale.US, "%.1f", absDiff)
                    + " lbs since " + startDate + " (as of " + currentDate + ").";
        }

        Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
    }

    // Create one horizontal row: [Date] [Weight] [Delete X]
    private void addRowView(long id, String date, double weight) {
        // Parent row horizontal
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(dp(8), dp(8), dp(8), dp(8));
        row.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));

        // Date column (weight = 1)
        TextView tvDate = new TextView(this);
        tvDate.setLayoutParams(weighted(1));
        tvDate.setText(date);
        tvDate.setTextSize(16);
        tvDate.setGravity(Gravity.START);
        tvDate.setPadding(0, 0, dp(8), 0);
        tvDate.setTypeface(tvDate.getTypeface(), android.graphics.Typeface.BOLD);

        // Weight column (weight = 1)
        TextView tvWeight = new TextView(this);
        tvWeight.setLayoutParams(weighted(1));
        tvWeight.setText(String.valueOf(weight));
        tvWeight.setTextSize(16);
        tvWeight.setGravity(Gravity.START);

        // Delete button (fixed size red "X")
        Button btnDelete = new Button(this);
        LinearLayout.LayoutParams delParams =
                new LinearLayout.LayoutParams(dp(36), dp(36));
        btnDelete.setLayoutParams(delParams);
        btnDelete.setText("X");
        btnDelete.setAllCaps(false);
        btnDelete.setTextColor(0xFFFFFFFF);
        btnDelete.setBackgroundColor(0xFFEF5350);
        btnDelete.setOnClickListener(v -> {
            db.deleteWeight(id);
            refreshGrid();
        });

        // Adds children to row and row to container
        row.addView(tvDate);
        row.addView(tvWeight);
        row.addView(btnDelete);
        rowsContainer.addView(row);
    }

    // Helpers for layout weights
    private LinearLayout.LayoutParams weighted(int weight) {
        LinearLayout.LayoutParams p =
                new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.weight = weight;
        return p;
    }

    private int dp(int value) {
        float d = getResources().getDisplayMetrics().density;
        return Math.round(value * d);
    }

    // Reads text safely and trim it
    private String safeText(EditText e) {
        CharSequence cs = e.getText();
        return cs == null ? "" : cs.toString().trim();
    }

    // Quick toast helper
    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }

    // Checks goal and sends an SMS if the new weight meets or beats the goal
    private void maybeSendGoalReachedSms(double newWeight) {
        // read saved goal from DB
        Double goal = db.getGoal(currentUser);
        if (goal == null) return;          // no goal set yet
        if (newWeight > goal) return;      // not reached yet

        // must have SEND_SMS permission
        boolean granted = ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED;
        if (!granted) {
            toast("Goal reached! Open SMS Settings to enable texting.");
            return;
        }

        // must have a saved phone number (set on the SMS screen)
        String phone = getNotifyPhone();
        if (phone == null || phone.isEmpty()) {
            toast("Goal reached! Set your number in SMS Settings.");
            return;
        }

        try {
            String msg = "Congrats! You reached your goal weight of " + goal + "!";
            SmsManager.getDefault().sendTextMessage(phone, null, msg, null, null);
            toast("Congrats! You reached your goal weight of " + goal + "! SMS sent.");
        } catch (SecurityException se) {
            toast("No permission to send SMS");
        } catch (Exception e) {
            toast("Failed to send SMS");
        }
    }

    // sends the SMS
    private void sendSms(String phone, String message) {
        try {
            SmsManager.getDefault().sendTextMessage(phone, null, message, null, null);
            // toast("SMS sent"); // optional test feedback
        } catch (SecurityException se) {
            toast("No permission to send SMS");
        } catch (Exception e) {
            toast("Failed to send SMS");
        }
    }
}
