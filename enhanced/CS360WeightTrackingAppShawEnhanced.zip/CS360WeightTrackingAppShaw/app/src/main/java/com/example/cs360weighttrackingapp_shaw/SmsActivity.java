package com.example.cs360weighttrackingapp_shaw;

import android.Manifest;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.text.InputType;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

/*
 * Shows current SMS permission state
 * Requests SEND_SMS runtime permission
 * Sends one simple test SMS when allowed
 * If denied, the rest of the app keeps working
 */
public class SmsActivity extends AppCompatActivity {

    // permission request code
    private static final int REQ_SEND_SMS = 101;
    private static final String PREFS = "auth_prefs";
    private static final String KEY_NOTIFY_PHONE = "notify_phone";

    // UI refs
    private TextView tvStatus;
    private Button btnRequest;
    private Button btnSendPreview;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms);

        // find views by id
        tvStatus = findViewById(R.id.tvStatus);
        btnRequest = findViewById(R.id.btnRequest);
        btnSendPreview = findViewById(R.id.btnSendPreview);

        // set initial UI state
        updateUi(hasSmsPermission());

        // ask for permission when tapped
        btnRequest.setOnClickListener(v -> {
            if (hasSmsPermission()) {
                toast("Permission already granted");
                updateUi(true);
            } else {
                ActivityCompat.requestPermissions(
                        this,
                        new String[]{Manifest.permission.SEND_SMS},
                        REQ_SEND_SMS
                );
            }
        });

        // send one simple test SMS if allowed
        btnSendPreview.setOnClickListener(v -> {
            if (!hasSmsPermission()) {
                toast("SMS permission not granted");
                return;
            }
            promptPhoneAndSend();
        });
    }

    // handles permission result and updates screen
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_SEND_SMS) {
            boolean granted = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
            updateUi(granted);
            if (!granted) {
                toast("Permission denied. App will continue without SMS.");
            }
        }
    }

    // checks current permission
    private boolean hasSmsPermission() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED;
    }

    // updates label and enables or disables preview button
    private void updateUi(boolean granted) {
        tvStatus.setText("Permission status: " + (granted ? "GRANTED" : "NOT GRANTED"));
        btnSendPreview.setEnabled(granted);
    }

    // asks for a phone number, then sends the simple test SMS
    private void promptPhoneAndSend() {
        final EditText input = new EditText(this);
        input.setHint("Enter phone");
        input.setInputType(InputType.TYPE_CLASS_PHONE);

        new AlertDialog.Builder(this)
                .setTitle("Send Test Notification")
                .setMessage("Enter your phone number to receive a test SMS.")
                .setView(input)
                .setPositiveButton("Send", (dialog, which) -> {
                    String number = input.getText() == null ? "" : input.getText().toString().trim();
                    if (number.isEmpty()) {
                        toast("Phone number required");
                        return;
                    }

                    // SAVE the number for future auto-SMS on the weights page
                    getSharedPreferences(PREFS, MODE_PRIVATE)
                            .edit()
                            .putString(KEY_NOTIFY_PHONE, number)
                            .apply();

                    // simple, generic test message
                    String message = "WeightTracker: Test notification.";
                    sendSms(number, message);
                })
                .setNegativeButton("Cancel", (DialogInterface d, int w) -> d.dismiss())
                .show();
    }

    // sends the SMS via system manager
    private void sendSms(String phone, String message) {
        try {
            SmsManager sms = SmsManager.getDefault();
            sms.sendTextMessage(phone, null, message, null, null);
            toast("SMS sent");
        } catch (SecurityException se) {
            toast("No permission to send SMS");
        } catch (Exception e) {
            toast("Failed to send SMS");
        }
    }

    // quick toast helper
    private void toast(String m) {
        Toast.makeText(this, m, Toast.LENGTH_SHORT).show();
    }
}
