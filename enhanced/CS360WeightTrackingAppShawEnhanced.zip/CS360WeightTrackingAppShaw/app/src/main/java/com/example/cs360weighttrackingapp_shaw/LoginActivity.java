package com.example.cs360weighttrackingapp_shaw;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

/*
 * Handles login and account creation using DBHelper.
 * On success, saves the current user and navigates to the weights screen.
 */
public class LoginActivity extends AppCompatActivity {

    // simple place to remember who is logged in
    private static final String PREFS = "auth_prefs";
    private static final String KEY_CURRENT_USER = "current_user";

    // Database and UI references
    private EditText etUser;
    private EditText etPass;
    private Button btnLogin;
    private Button btnCreate;
    private DBHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Find views by id
        etUser = findViewById(R.id.user_name);
        etPass = findViewById(R.id.Password);
        btnLogin = findViewById(R.id.login);
        btnCreate = findViewById(R.id.create_account);

        db = new DBHelper(this);

        // Login - checks username and password against the DB
        btnLogin.setOnClickListener(v -> {
            String u = safeText(etUser);
            String p = safeText(etPass);

            if (u.isEmpty() || p.isEmpty()) {
                toast("Enter username and password");
                return;
            }

            boolean ok = db.checkUser(u, p);
            if (ok) {
                saveCurrentUser(u);
                goToWeights();
            } else {
                toast("Invalid login. If you're new, tap Create Account.");
            }
        });

        // Create Account - inserts a new user, then auto login
        btnCreate.setOnClickListener(v -> {
            String u = safeText(etUser);
            String p = safeText(etPass);

            if (u.isEmpty() || p.isEmpty()) {
                toast("Choose a username and password");
                return;
            }

            boolean created = db.createUser(u, p);
            if (created) {
                toast("Account created. Welcome, " + u + "!");
                saveCurrentUser(u);
                goToWeights();
            } else {
                toast("Username already exists. Try a different one.");
            }
        });
    }

    // Reads text safely and trim it
    private String safeText(EditText e) {
        CharSequence cs = e.getText();
        return cs == null ? "" : cs.toString().trim();
    }

    // Quick toast helper
    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }

    // Remember the logged in user for other screens
    private void saveCurrentUser(String username) {
        SharedPreferences sp = getSharedPreferences(PREFS, MODE_PRIVATE);
        sp.edit().putString(KEY_CURRENT_USER, username).apply();
    }

    // Navigate to the users weights screen
    private void goToWeights() {
        Intent i = new Intent(this, DataGridActivity.class);
        startActivity(i);
        finish(); // close login so back doesn't return here
    }
}